from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib.auth.models import User,auth
from django.contrib import messages
from .models import Feature
# Create your views here.
def index(request):
    context={
        'name':'surya',
        'age':20,
        'nationality':'Indian'

    }#return render(request,'index.html',context)  this is to render the index.html content

    feature1=Feature()
    feature1.id =0
    feature1.name='Very Fast'
    feature1.details='it is compartively very fast then others'

    feature2=Feature()
    feature2.id =1
    feature2.name='high Transimission'
    feature2.details='it is compartively very fast then others devies'

    feature3=Feature()
    feature3.id =2
    feature3.name='responsive to all screens'
    feature3.details='it is compartively very fast then others objects'

    features=[feature1,feature2,feature3]
    
    return render(request,'index.html',{'features':features})

def register(request):
    if request.method=='POST':
        username=request.POST['username']
        first_name=request.POST['first_name']
        last_name=request.POST['last_name']
        email=request.POST['email']
        #phone_no=request.POST['phone_no']
        password=request.POST['password']
        password2=request.POST['password2']

        if password==password2:
            if User.objects.filter(email=email).exists():
                messages.info(request,'Email already exits')
                return redirect('register')
            elif User.objects.filter(username=username).exists():
                messages.info(request,'Username already exits')
                return redirect('register')
            #elif User.objects.filter(phone_no=phone_no).exists():
             #   messages.info(request,'phone number already exits')
             #   return redirect('register')'''
            elif User.objects.filter(first_name=first_name).exists():
                messages.info(request,'First name already exits')
                return redirect('register')
            else:
                user = User.objects.create_user(username=username,email=email,first_name=first_name,last_name=last_name,password=password)
                user.save();
                return redirect('studemp')
        else:
            messages.info(request,'password not the same')
            return redirect('register')
    else:
        return render(request,'register.html')

def counter(request):
    letters=request.POST['text']     #this is the place where the text from index.html is rendered
    amt_of_words=len(letters.split())
    return render(request,'counter.html',{'count':amt_of_words})

def login(request):
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['password']

        user = auth.authenticate(username=username,password=password)

        if user is not None:
            auth.login(request,user)
            return redirect('home') 
        else:
            messages.info(request,'Credential are not valid')
            return redirect('login')
    else:
        return render(request,'login.html')

def studemp(request):
    return render(request,'studemp.html')

'''def store(request):
    return HttpResponse('<h1>this is surya\'s store</h1>')'''
